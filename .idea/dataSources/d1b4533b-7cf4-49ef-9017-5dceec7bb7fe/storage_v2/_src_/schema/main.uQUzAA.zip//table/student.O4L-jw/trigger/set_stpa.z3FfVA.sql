CREATE TRIGGER set_stpa AFTER INSERT 
ON student
BEGIN
   UPDATE student
   SET stu_password=new.stu_num
   WHERE stu_num=new.stu_num;
END;


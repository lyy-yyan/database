CREATE TRIGGER set_tepa AFTER INSERT 
ON teacher
BEGIN
   UPDATE teacher
   SET tec_password=new.tec_num
   WHERE tec_num=new.tec_num;
END;

